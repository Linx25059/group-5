import scrapy

class GithubUserSpider(scrapy.Spider):
    name = "github_user"
    start_urls = ["https://github.com/110021085?tab=repositories"]

    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'FEED_EXPORT_ENCODING': 'utf-8',
        'ROBOTSTXT_OBEY': False,
    }

    def parse(self, response):
        # 使用你測試成功的選擇器抓取所有儲存庫連結
        for repo in response.css('h3 a'):
            repo_name = repo.css('::text').get().strip()
            repo_url = response.urljoin(repo.css('::attr(href)').get())
            
            # 抓取 About 描述 (位於同一個區塊內)
            about_text = repo.xpath('./ancestor::div[1]/following-sibling::div//p/text()').get()
            
            yield scrapy.Request(
                url=repo_url,
                callback=self.parse_details,
                meta={'name': repo_name, 'url': repo_url, 'about': about_text}
            )

    def parse_details(self, response):
        meta = response.meta
        
        # 判斷儲存庫是否為空 (檢查是否有檔案導航區塊)
        is_empty = response.css('div.blankslate').get() is not None or response.css('div.file-navigation').get() is None
        
        # 邏輯 1：關於 (About) 處理 [依照作業要求]
        about = meta['about']
        if not about or about.strip() == "":
            # 如果不為空，About 設定為 Repo Name；如果為空，設為 None
            about = meta['name'] if not is_empty else "None"

        # 邏輯 2：語言與提交次數 [依照作業要求]
        languages = "None"
        num_commits = "None"
        
        if not is_empty:
            languages = response.css('span.color-fg-default.text-bold.mr-1::text').getall()
            # 抓取 Commit 次數
            commit_text = response.css('span.d-none.d-sm-inline strong::text').get()
            num_commits = commit_text if commit_text else "None"

        yield {
            "URL": meta['url'],
            "About": about.strip() if about else about,
            "LastUpdated": response.css('relative-time::attr(datetime)').get(),
            "Languages": languages,
            "Number_of_Commits": num_commits
        }
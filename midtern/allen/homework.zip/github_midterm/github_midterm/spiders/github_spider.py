import scrapy


class GithubSpider(scrapy.Spider):
    name = "github_spider"
    allowed_domains = ["github.com"]
    start_urls = ["https://github.com/allen54347?tab=repositories"]


    def parse(self, response):
        repos = response.css('li[itemprop="owns"]')

        for repo in repos:
            repo_name = repo.css('a[itemprop="name codeRepository"]::text').get()
            if repo_name:
                repo_name = repo_name.strip()

            repo_url = response.urljoin(
                repo.css('a[itemprop="name codeRepository"]::attr(href)').get()
            )

            about = repo.css('p[itemprop="description"]::text').get()
            if about:
                about = about.strip()

            if not about:
                about = repo_name

            yield scrapy.Request(
                repo_url,
                callback=self.parse_repo,
                meta={
                    "repo_name": repo_name,
                    "about": about,
                    "repo_url": repo_url
                }
            )


    def parse_repo(self, response):
        repo_name = response.meta["repo_name"]
        about = response.meta["about"]
        repo_url = response.meta["repo_url"]

        page_text = "".join(response.css("body *::text").getall()).lower()

        is_empty_repo = (
            "quick setup" in page_text
            or "create a new file" in page_text
            or "create new file" in page_text
        )

        # Last Updated
        last_updated = response.css("relative-time::attr(datetime)").get()

        # Languages
        languages = None
        if not is_empty_repo:
            langs = response.css(
                'span[itemprop="programmingLanguage"]::text'
            ).getall()
            if langs:
                languages = ", ".join([l.strip() for l in langs])

        # Commits
        commits = None
        if not is_empty_repo:
            commits = response.css(
                'a[href$="/commits"] span::text'
            ).get()
            if commits:
                commits = commits.strip()

        yield {
            "name": repo_name,
            "url": repo_url,
            "about": about,
            "last_updated": last_updated,
            "languages": languages,
            "commits": commits
        }